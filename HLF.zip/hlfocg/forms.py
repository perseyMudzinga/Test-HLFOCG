from django.contrib.auth.models import User
from django import forms
from .models import Profile
from .models import Post
from .models import Comment
from .models import Announcement
from .models import QuestionReply


#Account Creation
class UserForm(forms.ModelForm):
	password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))
	username = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Username'}))
	first_name = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'First Name'}))
	last_name = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Last Name'}))
	email = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Email'}))

	class Meta:
		model = User
		fields = ['username', 'first_name', 'last_name', 'email', 'password']

#Login Form
class Login(forms.ModelForm):
	password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))
	email = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Email Address'}))

	class Meta:
		model = User
		fields = ['email', 'password']

#Create Profile Form

class DateInput(forms.DateInput):
    input_type = 'date'

class CreateProfileForm(forms.ModelForm):

	class Meta:
		model = Profile
		fields = ['user_picture', 'gender', 'date_of_birth', 'town_or_city', 'cellphone_number', 'address', 'country_of_residence', 'country_of_origin', 'mentor_or_mentee', 'career_field_of_interest', 'field_of_study', 'highest_qualification_aquired', 'institution', 'year_aquired', 'interests']
		

#Create Post Form	
class CreatePostForm(forms.ModelForm):

	class Meta:
		model = Post
		fields = ['post']

#Comment Form
class CommentForm(forms.ModelForm):

	class Meta:
		model = Comment
		fields = ['comment']

#Announcements
class CreateAnnouncementForm(forms.ModelForm):

	class Meta:
		model = Announcement
		fields = ['subject', 'announcement', 'external_link']



#Reply Form
class ReplyForm(forms.ModelForm):

	class Meta:
		model = QuestionReply
		fields = ['message']