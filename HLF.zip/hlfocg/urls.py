from django.conf.urls import url
from django.contrib import admin
from . import views

app_name = "hlfocg"

urlpatterns = [
	url(r'^$', views.login_view, name='login'),


	#Registration
	url(r'^register/$', views.user_registration, name='register'),
	url(r'^check_email/$', views.check_email, name='check_email'),

	# /user/editprofile/
	url(r'^createprofile/$', views.CreateProfile.as_view(), name='create_profile'),
	url(r'^editprofile/$', views.EditProfile.as_view(), name='edit_profile'),
	url(r'^login/$', views.login_view, name='login'),
	url(r'^logout/$', views.logout_view, name='logout'),
	url(r'^create_post/$', views.create_post, name='create_post'),
	url(r'^home/$', views.index, name='index'),
	url(r'^post/(?P<pk>[0-9]+)/$', views.fullPostView, name='full_post'),
	url(r'^post/comment/$', views.CommentPost.as_view(), name='comment'),
	url(r'^people/$', views.people, name='people'),

	#Announcements
	url(r'^announcements/$', views.announcements, name='announcements'),
	url(r'^create_announcement/$', views.AnnouncementCreate.as_view(), name='announce'),

	#Events
	url(r'^events/$', views.events, name='events'),
	url(r'^is_rsvp/(?P<event_id>[0-9]+)/$', views.rsvp, name='rsvp'),
	url(r'^is_interest/(?P<int_id>[0-9]+)/$', views.interested, name='interested'),

	#Contact us
	url(r'^contact_us/$', views.contact_us, name='contact_us'),
	url(r'^contact_thanks/$', views.contact_thanks, name='contact_thanks'),
	url(r'^questions/$', views.contact_us_questions, name='contact_us_questions'),
	url(r'^reply/(?P<pk>[0-9]+)/$', views.reply_page, name='reply'),
	url(r'^question/reply/$', views.ReplyUser.as_view(), name='reply_user'),

	#Messages
	url(r'^messages/$', views.rt_chat, name='messages'),
	url(r'^message/(?P<pk>[0-9]+)/$', views.conversationView, name='conversation'),
	url(r'^message/compose/$', views.composeMessage, name='compose_message'),
	url(r'^chat/$', views.chat, name='chat'),
	url(r'^new_messages/$', views.get_new_messages, name='new_messages'),

	#archives
	url(r'^archives/$', views.archives_home, name='archives_home'),
	url(r'^archives/videos/$', views.video_list, name='video_list'),
	url(r'^archives/images/$', views.picture_list, name='picture_list'),
	url(r'^archives/video/(?P<pk>[0-9]+)/$', views.archives_video, name='video'),
	url(r'^archives/document/(?P<pk>[0-9]+)/$', views.archives_document, name='document'),
	url(r'^upload_video/$', views.upload_video, name='upload_video'),
	url(r'^upload_image/$', views.upload_image, name='upload_image'),
	url(r'^upload_document/$', views.upload_document, name='upload_document'),
	url(r'^about/$', views.about, name='about'),


	#Careers
	url(r'^careers/$', views.careers, name='careers'),
	url(r'^career/(?P<title>.*)/$', views.career_page, name='career_page'),
	url(r'^careers/(?P<career_url>.*)/media/$', views.careers_picture_list, name='career_media'),
	url(r'^careers/(?P<career_url>.*)/videos/$', views.careers_video_list, name='career_videos'),
	url(r'^careers/(?P<career_url>.*)/documents/$', views.careers_document_list, name='career_documents'),
	url(r'^careers/(?P<career>.*)/contacts/$', views.career_contacts, name='career_contacts'),
	url(r'^career_update/$', views.career_url_update, name='career_update'),
	url(r'^follow_career/(?P<career>.*)/$', views.follow_career, name='follow_career'),
	url(r'^exit_career/(?P<career>.*)/$', views.exit_career, name='exit_career'),


	#Calendar
	url(r'^calendar/$', views.calendar, name='calendar'),


	#Bulletin
	url(r'^bulletin/$', views.bulletin, name='bulletin'),
	url(r'^bulletin/story/(?P<pk>[0-9]+)/$', views.bulletin_details, name='bulletin_details'),
	url(r'^bulletin/add/$', views.add_bulletin, name='bulletin_add'),

	#Contacts
	url(r'^contacts/add/(?P<username>.*)/$', views.add_contact, name='add_contact'),

	#Settings
	url(r'^settings/$', views.settings, name='settings'),

	#Companies
	url(r'^companies/$', views.companies, name='companies'),

	#Help
	url(r'^help/$', views.help, name='help'),
	url(r'^help_details/(?P<pk>[0-9]+)/$', views.help_details, name='help_details'),

]
