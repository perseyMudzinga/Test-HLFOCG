from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.views.generic import View
from .forms import CreateProfileForm
from .forms import CreatePostForm
from .forms import CommentForm
from .forms import CreateAnnouncementForm
from .forms import ReplyForm
from django.contrib.auth.models import User
from .models import Post
from .models import Profile
from .models import Announcement
from .models import Event
from .models import Notification
from .models import RSVP
from .models import Question
from .models import Message
from .models import Conversation
from .models import Interest
from .models import Video
from .models import Picture, Document
from .models import Career
from .models import CareerFollower
from .models import About
from .models import Bulletin
from .models import UserContact
from .models import HelpCategory
from .models import Help
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q
import base64
from random import uniform
from django.utils import timezone
from django.db import IntegrityError


def user_registration(request):
    if request.user.is_authenticated:
        return redirect('hlfocg:create_profile')
    if request.method == 'POST':
        firstname = request.POST["first_name"]
        lastname = request.POST["last_name"]
        email = request.POST["email"]
        password = request.POST["password"]
        strip_email = email.index("@")
        new_user = User()
        index = 0
        possible_usernames = [firstname.lower(), lastname.lower(), firstname.lower()+lastname.lower(), firstname.lower()+"."+lastname.lower(), "@"+email[0:strip_email].lower(), lastname.lower()+firstname.lower(), lastname.lower()+"."+firstname.lower(), lastname.lower()+"_"+firstname.lower(), firstname.lower()+"_"+lastname.lower() ]

        try:
            guest_user = User.objects.get(email=email)
            return HttpResponse("taken");
        except Exception as e:
            pass

        new_user.username = possible_usernames[index]
        new_user.first_name = firstname
        new_user.email = email
        new_user.last_name = lastname
        new_user.set_password(password)

        for un in possible_usernames:
            try:
                new_user.username = un
                new_user.save()
                break

            except IntegrityError as e:
                print un

        user = authenticate(username=new_user.username, password=password)
        if user is not None:
            notes = Notification(user_name=user)
            notes.save()
        if user.is_active:
            login(request, user)
            return HttpResponse("created")



    return render(request, 'hlfocg/register.html')

def check_email(request):
    if request.method == 'POST':
        email = request.POST["email"]
        try:
            guest_user = User.objects.get(email=email)
            return HttpResponse("taken");
        except Exception as e:
            return HttpResponse("available")
    return HttpResponse("")


#Login In user
def login_view(request):
    context = {'error':''}
    if request.user.is_authenticated:
        return redirect('hlfocg:index')
    if request.method == 'GET':
        return render(request, 'hlfocg/login.html', context)
    elif request.method == 'POST':

        try:
            guest_user = User.objects.get(email=request.POST['email'])
        except Exception as e:
            context = {'error':'This email address has no any account associated with it. Sign up to proceed.'}
            return render(request, 'hlfocg/login.html', context)

        user = authenticate(username=guest_user.username, password=request.POST['password'])
        if user is not None:
            if user.is_active:
                login(request, user)
                
                current_user = User.objects.get(username=guest_user.username)

                if current_user.last_name == '_company_':
                    return redirect('companies:home')
                    
                try:
                    current_user.profile
                    return redirect('hlfocg:index')
                except Exception:
                    return redirect('hlfocg:create_profile')
        context = {'error':'Username or Password is incorrect.'}
        return render(request, 'hlfocg/login.html', context)


#Login the user out
def logout_view(request):
    logout(request)
    return redirect('hlfocg:login')


#Code for creating a Profile
class CreateProfile(View):
    form_class = CreateProfileForm
    template_name = 'hlfocg/create_profile.html'

    def get(self, request):
        form = self.form_class(None)
        return render(request, self.template_name)

    def post(self, request):
        form = self.form_class(request.POST, request.FILES)

        if form.is_valid():

            profile = form.save(commit=False)

            user_picture = form.cleaned_data['user_picture']
            gender = form.cleaned_data['gender']
            date_of_birth = form.cleaned_data['date_of_birth']
            town_or_city = form.cleaned_data['town_or_city']
            cellphone_number = form.cleaned_data['cellphone_number']
            address = form.cleaned_data['address']
            country_of_residence = form.cleaned_data['country_of_residence']
            country_of_origin = form.cleaned_data['country_of_origin']

            mentor_or_mentee = form.cleaned_data['mentor_or_mentee']
            career_field_of_interest = form.cleaned_data['career_field_of_interest']
            field_of_study = form.cleaned_data['field_of_study']
            highest_qualification_aquired = form.cleaned_data['highest_qualification_aquired']
            institution = form.cleaned_data['institution']
            year_aquired = form.cleaned_data['year_aquired']
            interests = form.cleaned_data['interests']

            profile.user_name = request.user

            profile.save()

            if profile is not None:
                return HttpResponse("done")
        return HttpResponse("errors")


#Code for creating a Profile
class EditProfile(View):
    form_class = CreateProfileForm
    template_name = 'hlfocg/update_profile.html'

    def get(self, request):

        prof = Profile.objects.get(user_name=request.user)
        form_class = CreateProfileForm
        form = self.form_class(None)
        context = {"gender": prof.gender, "dob":prof.date_of_birth, "toc":prof.town_or_city, "cell":prof.cellphone_number, "address":prof.address, "cor":prof.country_of_residence, "coo": prof.country_of_origin, "mom":prof.mentor_or_mentee, "cfoi": prof.career_field_of_interest, "fos":prof.field_of_study, "hqa": prof.highest_qualification_aquired, "inst": prof.institution, "ya":prof.year_aquired, "interests":prof.interests}
        return render(request, self.template_name, context)

    def post(self, request):
        this_user = Profile.objects.get(user_name=request.user)
        form = self.form_class(request.POST, request.FILES)

        if form.is_valid():

            profile = form.save(commit=False)

            user_picture = form.cleaned_data['user_picture']
            gender = form.cleaned_data['gender']
            date_of_birth = form.cleaned_data['date_of_birth']
            town_or_city = form.cleaned_data['town_or_city']
            cellphone_number = form.cleaned_data['cellphone_number']
            address = form.cleaned_data['address']
            country_of_residence = form.cleaned_data['country_of_residence']
            country_of_origin = form.cleaned_data['country_of_origin']

            mentor_or_mentee = form.cleaned_data['mentor_or_mentee']
            career_field_of_interest = form.cleaned_data['career_field_of_interest']
            field_of_study = form.cleaned_data['field_of_study']
            highest_qualification_aquired = form.cleaned_data['highest_qualification_aquired']
            institution = form.cleaned_data['institution']
            year_aquired = form.cleaned_data['year_aquired']
            interests = form.cleaned_data['interests']

            if user_picture is not None:
                this_user.user_picture = user_picture

            this_user.gender = gender

            this_user.date_of_birth = date_of_birth

            this_user.town_or_city = town_or_city
            this_user.cellphone_number = cellphone_number
            this_user.address = address

            if country_of_residence is not None:
                this_user.country_of_residence = country_of_residence
            if country_of_origin is not None:
                this_user.country_of_origin = country_of_origin
            if mentor_or_mentee is not None:
                this_user.mentor_or_mentee = mentor_or_mentee

            this_user.career_field_of_interest = career_field_of_interest
            this_user.field_of_study = field_of_study

            if highest_qualification_aquired is not None:
                this_user.highest_qualification_aquired = highest_qualification_aquired

            this_user.institution = institution
            this_user.year_aquired = year_aquired
            this_user.interests = interests

            this_user.save(force_update=True)

            if this_user is not None:
                return HttpResponse("done")
        return HttpResponse(form.errors)


#Index / Homepage

def index(request):

    if not request.user.is_authenticated:
        return redirect('hlfocg:login')
    ann = ""
    bulletin = ""
    try:
        ann = Announcement.objects.all()[0]
        bulletin = Bulletin.objects.all()[0]
    except Exception as e:
        pass
    
    next_event = Event.objects.filter(event_date__gte=timezone.now()).order_by('event_date')
    event_not = None
    for event in next_event:
        event_not = event
        break

    user_careers = CareerFollower.objects.filter(user=request.user)

    user_careers_list = []

    for career in user_careers:
        user_careers_list.append(career)


    if len(user_careers_list) == 3:
        posts_list = Post.objects.filter(Q(circle=user_careers_list[0].career) | Q(circle=user_careers_list[1].career) | Q(circle=user_careers_list[2].career)  )
    elif len(user_careers_list) == 2:
        posts_list = Post.objects.filter(Q(circle=user_careers_list[0].career) | Q(circle=user_careers_list[1].career) )
    elif len(user_careers_list) == 1:
         posts_list = Post.objects.filter(Q(circle=user_careers_list[0].career))
    else:
        return redirect("hlfocg:careers")


    paginator = Paginator(posts_list, 20)
    page = request.GET.get('page')

    try:
        all_posts = paginator.page(page)
    except PageNotAnInteger:
        all_posts = paginator.page(1)
    except EmptyPage:
        all_posts = paginator.page(paginator.num_pages)

    context = {'all_posts': all_posts, "announcement": ann, 'bulletin':bulletin, 'next_event':event_not}
    return render(request, 'hlfocg/index.html', context)


# Create Timeline Post
def create_post(request):
    careers = CareerFollower.objects.filter(user=request.user)

    if request.method == 'POST':
        
        post = Post()

        post.post = request.POST['post']

        post_career = Career.objects.get(pk=request.POST['circle'])
        post.circle = post_career
        post.poster = request.user

        post.save()

        if post is not None:
        	return redirect('hlfocg:index')
        
    return render(request, 'hlfocg/timeline_post_box.html', {"all_careers": careers})


#View full posts
def fullPostView(request, pk):

    post = Post.objects.get(pk=pk)
    comment_list = post.comment_set.all()

    paginator = Paginator(comment_list, 5, 3)
    page = request.GET.get('page')

    try:
        comments = paginator.page(page)
    except PageNotAnInteger:
        comments = paginator.page(1)
    except EmptyPage:
        comments = paginator.page(paginator.num_pages)
    return render(request, 'hlfocg/full_post.html', {'post': post, 'comments':comments})


#Commenting Form
class CommentPost(View):
    form_class = CommentForm

    def get(self, request):
        form = self.form_class(request.GET)

        if form.is_valid():
            comment_form = form.save(commit=False)

            comment = form.cleaned_data['comment']
            post_id = request.GET['post_id']
            last_page = request.GET['last_page']

            post_to_comment = Post.objects.get(pk=post_id)

            comment_form.commenter = request.user
            comment_form.post = post_to_comment

            comment_form.save()
            return redirect('hlfocg:full_post', post_id)


#Show contacts
def people(request):

    if not request.user.is_authenticated:
        return redirect('hlfocg:login')

    people_list = User.objects.all()

    paginator = Paginator(people_list, 20)
    page = request.GET.get('page')

    try:
        all_people = paginator.page(page)
    except PageNotAnInteger:
        all_people = paginator.page(1)
    except EmptyPage:
        all_people = paginator.page(paginator.num_pages)

    context = {'all_people': all_people}
    return render(request, 'hlfocg/people/people.html', context)


#Show announcements
def announcements(request):

    if not request.user.is_authenticated:
        return redirect('hlfocg:login')

    noty = Notification.objects.get(user_name=request.user)
    noty.announcement = 0
    noty.save()

    announcement_list = Announcement.objects.all()

    paginator = Paginator(announcement_list, 20)
    page = request.GET.get('page')

    try:
        all_announcements = paginator.page(page)
    except PageNotAnInteger:
        all_announcements = paginator.page(1)
    except EmptyPage:
        all_announcements = paginator.page(paginator.num_pages)

    context = {'all_announcements': all_announcements}
    return render(request, 'hlfocg/announcements.html', context)


def notify(request, name):
    print name
    all_nots = Notification.objects.all()
    return redirect('admin')


#Announcements
class AnnouncementCreate(View):
    form_class = CreateAnnouncementForm
    template_name = 'hlfocg/c_announcement.html'

    def get(self, request):
        form = self.form_class(None)
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = self.form_class(request.POST)

        if form.is_valid():

            announcement_form = form.save(commit=False)

            subject = form.cleaned_data['subject']
            announcement = form.cleaned_data['announcement']
            external_link = form.cleaned_data['external_link']

            announcement_form.poster = request.user
            announcement_form.save()

            if announcement_form is not None:

                all_users = User.objects.all();

                for _user in all_users:
                    _user.notification.announcement += 1
                    noty = Notification.objects.get(user_name=_user)
                    noty.announcement += 1
                    noty.save()

                return redirect('hlfocg:announcements')

        return render(request, self.template_name, {'form': form})




#Messages

def messages(request):

    if not request.user.is_authenticated:
        return redirect('hlfocg:login')

    message_list = Message.objects.filter(Q(sender=request.user) | Q(receiver=request.user))

    paginator = Paginator(message_list, 20)
    page = request.GET.get('page')

    try:
        all_messages = paginator.page(page)
    except PageNotAnInteger:
        all_messages = paginator.page(1)
    except EmptyPage:
        all_messages = paginator.page(paginator.num_pages)

    context = {'all_messages': all_messages}
    return render(request, 'hlfocg/messages.html', context)


def rt_chat(request):

    if not request.user.is_authenticated:
        return redirect('hlfocg:login')
    return render(request, 'hlfocg/chat/chat.html')


#Conversation
def conversationView(request, pk):

    try:
        message = Message.objects.get(Q(pk=pk, sender=request.user) | Q(pk=pk, receiver=request.user))
        all_messages = Message.objects.filter(Q(sender=request.user) | Q(receiver=request.user))
    except Exception as e:
        pass


    new_messages = Conversation.objects.filter(message=message, read=False, receiver_c=request.user)

    for messag in new_messages:
        if messag.receiver_c == request.user:
            messag.read = True
            messag.save()

    notification = Notification.objects.get(user_name=request.user)

    if notification.messages > 0:
        notification.messages = 0;
        notification.save()


    conv_list = message.conversation_set.all()

    paginator = Paginator(conv_list, 50, 3)
    page = request.GET.get('page')

    try:
        messages = paginator.page(page)
    except PageNotAnInteger:
        messages = paginator.page(1)
    except EmptyPage:
        messages = paginator.page(paginator.num_pages)
    return render(request, 'hlfocg/conversation.html', {'message': message, 'messages':messages, 'all_messages':all_messages})


#Creating the Message
def composeMessage(request):
    if request.method == 'GET':
        try:
            to = User.objects.get(username=request.GET["to"])
        except Exception as e:
            to = ""
        try:
            fromhlf = request.GET["from"]
        except Exception as e:
            fromhlf = ""

        return render(request, 'hlfocg/compose_message.html', {"to":to, "from_h":fromhlf})
    if request.method == 'POST':
        rec = User.objects.get(username=request.POST["receiver"])
        sender = request.user
        try:
            conversation = Message.objects.get(Q(sender=sender, receiver=rec) | Q(sender=rec, receiver=request.user))
            return redirect('hlfocg:conversation',conversation.pk)
        except Exception as t:
            pass
        new_message = Message()
        new_message.sender = sender
        new_message.receiver = User.objects.get(username=request.POST["receiver"])
        new_message.message_to_display = request.POST["message"]
        new_message.subject = request.POST["subject"]
        new_message.message = request.POST["message"]

        new_message.save()

        notification = Notification.objects.get(user_name=new_message.receiver)
        notification.messages +=1;
        notification.save()

        if new_message is not None:
            return redirect('hlfocg:messages')
    return render(request, 'hlfocg/compose_message.html')


def chat(request):
    if request.method == 'GET':
        new_chat = Conversation()
        new_chat.message = Message.objects.get(pk=request.GET["message_id"])
        new_chat.sender_c = request.user
        new_chat.receiver_c = User.objects.get(username=request.GET["receiver_c"])
        new_chat.message_body = request.GET["message_body"]
        new_chat.save()

        this_message = Message.objects.get(pk=request.GET["message_id"])
        this_message.message_to_display = request.GET["message_body"]
        this_message.save()

        notification = Notification.objects.get(user_name=new_chat.receiver_c)
        notification.messages +=1;
        notification.save()

        if new_chat is not None:
            return HttpResponse("done")
        else:
            return HttpResponse("failed")
    return HttpResponse("none")


def get_new_messages(request):
    if request.method == 'GET':
        mssg = Message.objects.get(pk=request.GET["message_id"])
        new_messages = Conversation.objects.filter(message=mssg, read=False, receiver_c=request.user)

        for messag in new_messages:
            if messag.receiver_c == request.user:
                messag.read = True
                messag.save()

        notification = Notification.objects.get(user_name=request.user)

        if notification.messages > 0:
            notification.messages = 0;
            notification.save()
        if len(new_messages) == 0:
            return HttpResponse("no messages")
        else:
            return render(request, 'hlfocg/cons.html', {"new_messages":new_messages})
    return HttpResponse("no new messages")

#End Of Messages


#archives
def archives_home(request):
    if not request.user.is_authenticated:
        return redirect('hlfocg:login')

    document_list = Document.objects.all()

    paginator = Paginator(document_list, 20)
    page = request.GET.get('page')

    try:
        all_documents = paginator.page(page)
    except PageNotAnInteger:
        all_documents = paginator.page(1)
    except EmptyPage:
        all_documents = paginator.page(paginator.num_pages)

    context = {'all_documents': all_documents}
    return render(request, 'hlfocg/archives/archives_home.html', context)

def archives_document(request, pk):
    document = Document.objects.get(pk=pk)
    return render(request, 'hlfocg/archives/archives_document.html', {'document': document})


def archives_video(request, pk):
    video = Video.objects.get(pk=pk)
    return render(request, 'hlfocg/archives/archives_video.html', {'video': video})


#Upload Page
def upload_video(request):
    if request.method == 'POST':
        new_video = Video();
        new_video.uploader = request.user
        new_video.title = request.POST["title"]
        new_video.description = request.POST["description"]
        new_video.circle = Career.objects.get(pk=request.POST["circle"])
        image_data = request.POST['thumbnail']+ "========"
        image_data = image_data[image_data.find(",")+1:]
        image_name = uniform(10000000, 90000000)
        image_name = str(image_name)
        image_name = image_name.replace(".", "")
        imgdata = base64.b64decode(image_data)
        filename = 'media/video_thumbs'+image_name+'.jpg'
        with open(filename, 'wb') as f:
            f.write(imgdata)

        new_video.thumbnail = filename.strip('media/')
        new_video.thumb = image_data

        new_video.video = request.FILES["video"]

        new_video.save()
        if new_video is not None:
            return HttpResponse("done")

    careers = Career.objects.all()
    return render(request, 'hlfocg/archives/upload_video.html', {"all_careers": careers})


def upload_image(request):
    if request.method == 'POST':
        new_image = Picture();
        new_image.uploader = request.user
        new_image.title = request.POST["title"]
        new_image.description = request.POST["description"]
        new_image.image = request.FILES["image"]
        new_image.image_thumbnail = request.FILES["image"]
        new_image.circle = Career.objects.get(pk=request.POST["circle"])
        new_image.save()
        if new_image is not None:
            return HttpResponse("done")

    careers = Career.objects.all()
    return render(request, 'hlfocg/archives/upload_image.html', {"all_careers": careers})


def upload_document(request):
    if request.method == 'POST':
        document = Document();
        document.uploader = request.user
        document.title = request.POST["title"]
        document.description = request.POST["description"]
        document.document = request.FILES["document"]
        document.circle = Career.objects.get(pk=request.POST["circle"])
        document.save()
        if document is not None:
            return HttpResponse("done")

    careers = Career.objects.all()
    return render(request, 'hlfocg/archives/upload_document.html', {"all_careers": careers})

#Show Videos
def video_list(request):

    if not request.user.is_authenticated:
        return redirect('hlfocg:login')

    video_list = Video.objects.all()

    paginator = Paginator(video_list, 20)
    page = request.GET.get('page')

    try:
        all_videos = paginator.page(page)
    except PageNotAnInteger:
        all_videos = paginator.page(1)
    except EmptyPage:
        all_videos = paginator.page(paginator.num_pages)

    context = {'all_videos': all_videos}
    return render(request, 'hlfocg/archives/videos.html', context)


#Show Pictures
def picture_list(request):

    if not request.user.is_authenticated:
        return redirect('hlfocg:login')

    picture_list = Picture.objects.all()

    paginator = Paginator(picture_list, 20)
    page = request.GET.get('page')

    try:
        all_pictures = paginator.page(page)
    except PageNotAnInteger:
        all_pictures = paginator.page(1)
    except EmptyPage:
        all_pictures = paginator.page(paginator.num_pages)

    context = {'all_pictures': all_pictures}
    return render(request, 'hlfocg/archives/images.html', context)


def video_thumb(request, pk):
    image = Video.objects.get(pk=pk)
    image_data = image.thumb
    return HttpResponse(image_data, content_type='image/png')


def about(request):
    about = About.objects.get(pk=1)
    return render(request, 'hlfocg/about.html', {"about":about})


def careers(request):
    all_careers = Career.objects.all()
    career_followers = CareerFollower.objects.filter(user=request.user)
    car_str = ""
    for a in career_followers:
    	car_str += a.career.career_url+" "

    try:
        error = request.GET["error"]
    except Exception as e:
        error = ""
    
    return render(request, 'hlfocg/careers/careers.html', {"all_careers":all_careers, "career_followers": car_str, "error":error})


def career_page(request, title):
    if not request.user.is_authenticated:
        return redirect('hlfocg:login')

    career = Career.objects.get(career_url=title)
    posts_list = Post.objects.filter(circle=career)
    paginator = Paginator(posts_list, 20)
    page = request.GET.get('page')

    try:
        all_posts = paginator.page(page)
    except PageNotAnInteger:
        all_posts = paginator.page(1)
    except EmptyPage:
        all_posts = paginator.page(paginator.num_pages)

    context = {'all_posts': all_posts, 'career':career}

    return render(request, 'hlfocg/careers/career_page.html', context)


def career_url_update(request):
    all_careers = Career.objects.all()
    for career in all_careers:
        career_title = career.title.lower()
        career.career_url = career_title.replace(" ", "_")
        career.save()
    return redirect("hlfocg:careers")


#Show career videos
def careers_video_list(request, career_url):
	career = Career.objects.get(career_url=career_url)
	video_list = Video.objects.filter(circle=career)
	paginator = Paginator(video_list, 20)
	page = request.GET.get('page')
	try:
		all_videos = paginator.page(page)
	except PageNotAnInteger:
		all_videos = paginator.page(1)
	except EmptyPage:
		all_videos = paginator.page(paginator.num_pages)
	context = {'all_videos': all_videos, 'career':career}
	return render(request, 'hlfocg/careers/videos.html', context)


#Show career videos
def careers_document_list(request, career_url):
    career = Career.objects.get(career_url=career_url)
    document_list = Document.objects.filter(circle=career)
    paginator = Paginator(document_list, 20)
    page = request.GET.get('page')
    try:
        all_documents = paginator.page(page)
    except PageNotAnInteger:
        all_documents = paginator.page(1)
    except EmptyPage:
        all_documents = paginator.page(paginator.num_pages)
    context = {'all_documents': all_documents, 'career':career}
    return render(request, 'hlfocg/careers/documents.html', context)


#Show Pictures
def careers_picture_list(request, career_url):

    career = Career.objects.get(career_url=career_url)
    picture_list = Picture.objects.filter(circle=career)

    paginator = Paginator(picture_list, 20)
    page = request.GET.get('page')

    try:
        all_pictures = paginator.page(page)
    except PageNotAnInteger:
        all_pictures = paginator.page(1)
    except EmptyPage:
        all_pictures = paginator.page(paginator.num_pages)

    context = {'all_pictures': all_pictures, 'career':career}
    return render(request, 'hlfocg/careers/images.html', context)


#Follow Career

def follow_career(request, career):
    career_get = Career.objects.get(career_url=career)
    try:
        f_num = CareerFollower.objects.filter(user=request.user)
        print len(f_num)
        if len(f_num) >= 3:
            return redirect("http://127.0.0.1:8000/hlfocg/careers/?error=Maximum number of cirlcles reached")
    except Exception as e:
        pass
    cf = CareerFollower()
    cf.career = career_get
    cf.user = request.user
    cf.save()
    
    return redirect("http://127.0.0.1:8000/hlfocg/careers/?error=You have successfully joined "+career_get.title)


#Leave Career

def exit_career(request, career):
    career_get = Career.objects.get(career_url=career)
    cf = CareerFollower.objects.get(user=request.user, career=career_get)
    cn = career_get.title
    cf.delete()
    
    return redirect("http://127.0.0.1:8000/hlfocg/careers/?error=You have successfully exited "+cn)

#Career Contacts

def career_contacts(request, career):
	career_get = Career.objects.get(career_url=career)
	print career_get
	return render(request, 'hlfocg/careers/contacts.html', {"career":career_get})



def calendar(request):
    if request.method == 'POST':
        new_event = Event();
        new_event.poster = request.user
        new_event.subject = request.POST["subject"]
        new_event.description = request.POST["description"]
        new_event.event_date = request.POST["event_date"]
        new_event.location = request.POST["location"]
        new_event.external_link = request.POST["external_link"]
        new_event.start_time = request.POST["start_time"]
        new_event.end_time = request.POST["end_time"]

        if request.POST["is_rsvp"] == "true":
            new_event.is_rsvp = True
        else:
            new_event.is_rsvp = False

        if request.POST["is_int"] == "true":
            new_event.is_interested = True
        else:
            new_event.is_interested = False

        notification = Notification.objects.all()
        for nots in notification:
            nots.events = nots.events + 1
            nots.save()
            print nots.events

        new_event.save()
        if new_event is not None:
            return HttpResponse("done")

    my_events = Event.objects.all()
    if not request.user.is_staff:
        return render(request, 'hlfocg/calendar/user_calendar.html', {"all_events":my_events})
    return render(request, 'hlfocg/calendar/calendar.html', {"all_events":my_events})

    
    

#Show Events
def events(request):

    if not request.user.is_authenticated:
        return redirect('hlfocg:login')

    noty = Notification.objects.get(user_name=request.user)
    noty.announcement = 0
    noty.save()

    event_list = Event.objects.all()

    paginator = Paginator(event_list, 20)
    page = request.GET.get('page')

    try:
        all_events = paginator.page(page)
    except PageNotAnInteger:
        all_events = paginator.page(1)
    except EmptyPage:
        all_events = paginator.page(paginator.num_pages)

    context = {'all_events': all_events}
    return render(request, 'hlfocg/events/events.html', context)	


#RSVP
def rsvp(request, event_id):
    event = Event.objects.get(id=event_id)
    check = RSVP.objects.filter(r_user=request.user,r_ann=event)
    if len(check) is 0:
        new_rsvp = RSVP(r_user=request.user,r_ann=event)
        new_rsvp.save()
    return HttpResponse(len(event.rsvp_set.all()))


#RSVP
def interested(request, int_id):
    event = Event.objects.get(id=int_id)
    check = Interest.objects.filter(i_user=request.user,i_ann=event)
    if len(check) is 0:
        new_int = Interest(i_user=request.user,i_ann=event)
        new_int.save()
    return HttpResponse(len(event.interest_set.all()))


#Bulletin
def bulletin(request):
    bulletin_list = Bulletin.objects.all()

    paginator = Paginator(bulletin_list, 20)
    page = request.GET.get('page')

    try:
        all_bulletin = paginator.page(page)
    except PageNotAnInteger:
        all_bulletin = paginator.page(1)
    except EmptyPage:
        all_bulletin = paginator.page(paginator.num_pages)

    context = {'all_bulletin': all_bulletin}

    return render(request, 'hlfocg/bulletin/bulletin.html', context)

#Bulletin
def bulletin_details(request, pk):

    bulletin = Bulletin.objects.get(pk=pk)

    return render(request, 'hlfocg/bulletin/bulletin_more.html', {"bulletin":bulletin})

#Add Bulletin
def add_bulletin(request):

    if request.method == 'POST':
        bulletin = Bulletin();
        bulletin.writer = request.user
        bulletin.title = request.POST["title"]
        bulletin.story = request.POST["bulletin_story"]
        image_data = request.POST['bulletin_image']+ "========"
        image_data = image_data[image_data.find(",")+1:]
        image_name = uniform(10000000, 90000000)
        image_name = str(image_name)
        image_name = image_name.replace(".", "")
        imgdata = base64.b64decode(image_data)
        filename = 'media/bulletin/'+image_name+'.jpg'
        with open(filename, 'wb') as f:
            f.write(imgdata)

        filename = filename.strip("media/")
        bulletin.image = filename
        bulletin.orientation = request.POST["orientation"]

        bulletin.save()
        if bulletin is not None:
            return HttpResponse("done"+str(bulletin.pk))

    return render(request, 'hlfocg/bulletin/add_bulletin.html')


def contact_us(request):
    if request.method == 'POST':
        question = Question();
        question.contact = request.user
        question.subject = request.POST["subject"]
        question.message = request.POST["message"]
        question.status = True
        question.reply_id = 0

        question.save()
        if question is not None:
            return redirect("hlfocg:contact_thanks")
    return render(request, 'hlfocg/contact_us/contact.html')

def contact_thanks(request):
    return render(request, 'hlfocg/contact_us/thanks.html')


#Contact Reply
def contact_us_questions(request):
    if request.user.is_staff:
        question_list = Question.objects.all()
    else:
        question_list = Question.objects.filter(contact=request.user)

    paginator = Paginator(question_list, 20)
    page = request.GET.get('page')

    try:
        all_questions = paginator.page(page)
    except PageNotAnInteger:
        all_questions = paginator.page(1)
    except EmptyPage:
        all_questions = paginator.page(paginator.num_pages)

    context = {'all_questions': all_questions}

    return render(request, 'hlfocg/contact_us/reply.html', context)





#View full posts
def reply_page(request, pk):

    question = Question.objects.get(pk=pk)
    reply_list = question.questionreply_set.all()

    paginator = Paginator(reply_list, 5, 3)
    page = request.GET.get('page')

    try:
        replies = paginator.page(page)
    except PageNotAnInteger:
        replies = paginator.page(1)
    except EmptyPage:
        replies = paginator.page(paginator.num_pages)
    return render(request, 'hlfocg/contact_us/replies.html', {'question': question, 'replies':replies})





#Commenting Form
class ReplyUser(View):
    form_class = ReplyForm

    def get(self, request):
        form = self.form_class(request.GET)

        if form.is_valid():
            reply_form = form.save(commit=False)

            message = form.cleaned_data['message']
            question_id = request.GET['question_id']

            question = Question.objects.get(pk=question_id)

            reply_form.user_replying = request.user
            reply_form.question = question

            if request.user.is_staff:
                question.status = False
            else:
                question.status = True

            reply_form.save()
            return redirect('hlfocg:reply', question_id)



def add_contact(request, username):
    contact = User.objects.get(username=username)

    try:
        uc = UserContact.objects.get(user=request.user, contact=contact)
        return HttpResponse("already in contacts")
    except Exception as e:
        pass

    new_contact = UserContact()
    new_contact.user = request.user
    new_contact.contact = contact
    new_contact.save()

    if new_contact is not None:
            return HttpResponse("added")


def contacts(request):
    return render(request, 'hlfocg/contacts/contacts.html')


#Settings Page
def settings(request):
    if request.method == 'POST':
        user_name = request.user.username
        if request.user.check_password(request.POST["old"]):
            this_user = User.objects.get(username=request.user.username)
            this_user.set_password(request.POST["new_password"])
            this_user.save()
            user = authenticate(username=user_name, password=request.POST["new_password"])
            if user is not None:
                if user.is_active:
                    login(request, user)
            return HttpResponse("successful")
        else:
            return HttpResponse("failed")
    return render(request, 'hlfocg/settings/settings.html')


#Companies Page

def companies(request):
    return render(request, 'hlfocg/companies/companies.html')


#Help
def help(request):
    categories = HelpCategory.objects.all()

    context = {'categories': categories}

    return render(request, 'hlfocg/help/help.html', context)

def help_details(request, pk):
    topic = Help.objects.get(pk=pk)
    return render(request, 'hlfocg/help/details.html', {'topic':topic})