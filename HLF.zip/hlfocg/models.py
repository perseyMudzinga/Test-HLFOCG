from django.db import models
from imagekit.models import ProcessedImageField
from imagekit.processors import ResizeToFill
from imagekit.models import ImageSpecField
from django.contrib.auth.models import User
from django.core.urlresolvers import reverse
from .validators import validate_video, validate_document
from .validators import validate_image



class Career(models.Model):
	title = models.CharField(max_length=500)
	description = models.CharField(max_length=2500, null=True, blank=True)
	career_url = models.CharField(max_length=500)

	def __str__(self):
		return str(self.title)

	class Meta:
		ordering  = ['title']



#Profile Details
class Profile(models.Model):
	NA = ''
	MALE = 'MALE'
	FEMALE = 'FEMALE'
	GENDER_CHOICES = (
		(NA, 'N/A'),
		(MALE, 'MALE'),
		(FEMALE, 'FEMALE'),
	)

	user_name = models.OneToOneField(User, on_delete=models.CASCADE)
	user_picture = ProcessedImageField(upload_to='avatars',blank=True,
                                           processors=[ResizeToFill(300, 300)],
                                           format='JPEG',
                                           options={'quality': 60})
	gender = models.CharField(max_length=6,choices=GENDER_CHOICES,default=NA)
	date_of_birth = models.DateField(auto_now=False, auto_now_add=False)
	town_or_city = models.CharField(max_length=200)
	cellphone_number = models.CharField(max_length=15)
	address = models.CharField(max_length=500)
	country_of_residence = models.CharField(max_length=200)
	country_of_origin = models.CharField(max_length=200)

	mentor_or_mentee = models.CharField(max_length=2)
	career_field_of_interest = models.CharField(max_length=200)
	field_of_study = models.CharField(max_length=200)
	highest_qualification_aquired = models.CharField(max_length=16)
	institution = models.CharField(max_length=200)
	year_aquired = models.CharField(max_length=4)
	interests = models.TextField(max_length=1000)
	

	def __str__(self):
		return str(self.user_name)
		

#Posts
class Post(models.Model):
	poster = models.ForeignKey(User, on_delete=models.CASCADE)
	circle = models.ForeignKey(Career, on_delete=models.CASCADE)
	post = models.TextField(max_length=1500)
	time = models.DateTimeField(auto_now=True)

	class Meta:
		ordering  = ['-time']

	def __str__(self):
		return str(self.poster)+" "+ str(self.time)

#Comments to Posts
class Comment(models.Model):
	post = models.ForeignKey(Post, on_delete=models.CASCADE)
	commenter = models.ForeignKey(User, on_delete=models.CASCADE)
	comment = models.CharField(max_length=1500)
	time_commented = models.DateTimeField(auto_now=True)

	class Meta:
		ordering  = ['time_commented']

	def __str__(self):
		return str(self.commenter)+" - "+ str(self.time_commented)


#Announcements
class Announcement(models.Model):
	poster = models.ForeignKey(User, on_delete=models.CASCADE)
	subject = models.CharField(max_length=200)
	announcement =  models.TextField(max_length=2500)
	location = models.CharField(max_length=200, null=True, blank=True)
	posting_date = models.DateTimeField(auto_now=True)
	external_link = models.URLField(null=True, blank=True)

	class Meta:
		ordering  = ['-posting_date']

	def __str__(self):
		return str(self.poster)+" - "+ str(self.subject)


#Notifications	
class Notification(models.Model):
	user_name = models.OneToOneField(User, on_delete=models.CASCADE)
	announcement = models.IntegerField(null=True, blank=True, default=0)
	messages = models.IntegerField(null=True, blank=True, default=0)
	events = models.IntegerField(null=True, blank=True, default=0)

	def __str__(self):
		return str(self.user_name)


class Message(models.Model):
	sender = models.ForeignKey(User, on_delete=models.CASCADE)
	receiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name="messages", related_query_name="message")
	message_marker = models.TextField(max_length=500)
	subject = models.TextField(max_length=500, null=True, blank=True)
	message = models.TextField(max_length=2500)
	message_to_display = models.TextField(max_length=2500)
	read = models.BooleanField(default=False)
	time = models.DateTimeField(auto_now=True)

	class Meta:
		ordering  = ['-time']

	def __str__(self):
		return str(self.sender) +" --> "+str(self.receiver)

class Conversation(models.Model):
	message = models.ForeignKey(Message, on_delete=models.CASCADE)
	sender_c = models.ForeignKey(User, on_delete=models.CASCADE)
	receiver_c = models.ForeignKey(User, on_delete=models.CASCADE, related_name="conversations", related_query_name="conversation")
	message_body = models.TextField(max_length=2500)
	read = models.BooleanField(default=False)
	time = models.DateTimeField(auto_now=True)

	def __str__(self):
		return str(self.sender_c)+" -> "+str(self.receiver_c)



#Media

class Video(models.Model):
	uploader = models.ForeignKey(User, on_delete=models.CASCADE)
	title = models.CharField(max_length=500)
	circle = models.ForeignKey(Career, on_delete=models.CASCADE)
	description = models.CharField(max_length=2500, null=True, blank=True)
	thumbnail = ProcessedImageField(upload_to='video_thumbs',blank=True,
                                           processors=[ResizeToFill(250, 150)],
                                           format='JPEG',
                                           options={'quality': 60}, null=True)
	video = models.FileField(upload_to='videos/%Y/%m/%d/', validators=[validate_video])
	time = models.DateTimeField(auto_now=True)

	class Meta:
		ordering  = ['-time']

	def __str__(self):
		return str(self.title)


class Picture(models.Model):
	uploader = models.ForeignKey(User, on_delete=models.CASCADE)
	circle = models.ForeignKey(Career, on_delete=models.CASCADE)
	title = models.CharField(max_length=500)
	description = models.CharField(max_length=2500, null=True, blank=True)
	image = models.ImageField(upload_to='images/%Y/%m/%d/', validators=[validate_image])
	image_thumbnail = ProcessedImageField(upload_to='thumbs',blank=True,
                                           processors=[ResizeToFill(250, 150)],
                                           format='JPEG',
                                           options={'quality': 60}, null=True)
	time = models.DateTimeField(auto_now=True)

	class Meta:
		ordering  = ['-time']

	def __str__(self):
		return str(self.title)


class Document(models.Model):
	uploader = models.ForeignKey(User, on_delete=models.CASCADE)
	circle = models.ForeignKey(Career, on_delete=models.CASCADE)
	title = models.CharField(max_length=500)
	description = models.CharField(max_length=2500, null=True, blank=True)
	document = models.ImageField(upload_to='documents/%Y/%m/%d/', validators=[validate_document])
	time = models.DateTimeField(auto_now=True)

	class Meta:
		ordering  = ['-time']

	def __str__(self):
		return str(self.title)


class About(models.Model):
	about = models.TextField()


class CareerFollower(models.Model):
	career = models.ForeignKey(Career, on_delete=models.CASCADE)
	user = models.ForeignKey(User, on_delete=models.CASCADE)

	def __str__(self):
		return str(self.user)+" -> "+str(self.career)


#Event
class Event(models.Model):
	poster = models.ForeignKey(User, on_delete=models.CASCADE)
	subject = models.CharField(max_length=200)
	description =  models.TextField(max_length=2500)
	event_date = models.DateField(auto_now=False, auto_now_add=False, null=True, blank=True)
	location = models.CharField(max_length=200, null=True, blank=True)
	posting_date = models.DateTimeField(auto_now=True)
	is_rsvp = models.BooleanField()
	is_interested = models.BooleanField()
	start_time = models.CharField(max_length=50)
	end_time = models.CharField(max_length=50)
	external_link = models.URLField(null=True, blank=True)

	class Meta:
		ordering  = ['-posting_date']

	def __str__(self):
		return str(self.poster)+" - "+ str(self.subject)

#Is RVSP
class RSVP(models.Model):
	r_user = models.ForeignKey(User, on_delete=models.CASCADE)
	r_ann = models.ForeignKey(Event, on_delete=models.CASCADE)

	def __str__(self):
		return str(self.r_user)

#Is Interested
class Interest(models.Model):
	i_user = models.ForeignKey(User, on_delete=models.CASCADE)
	i_ann = models.ForeignKey(Event, on_delete=models.CASCADE)

	def __str__(self):
		return str(self.i_user)



class Bulletin(models.Model):
	writer = models.ForeignKey(User, on_delete=models.CASCADE)
	title = models.CharField(max_length=500)
	story = models.TextField()
	image = models.ImageField(upload_to='images/%Y/%m/%d/', validators=[validate_image])
	orientation = models.CharField(max_length=10)
	time = models.DateTimeField(auto_now=True)

	class Meta:
		ordering  = ['-time']

	def __str__(self):
		return str(self.title)

class Question(models.Model):
	contact = models.ForeignKey(User, on_delete=models.CASCADE)
	subject = models.CharField(max_length=500)
	message = models.CharField(max_length=2500)
	time = models.DateTimeField(auto_now=True)
	status = models.BooleanField()
	reply_id = models.IntegerField(null=True, blank=True, default=0)


	class Meta:
		ordering  = ['-time']

	def __str__(self):
		return str(self.contact)

class QuestionReply(models.Model):
	question = models.ForeignKey(Question, on_delete=models.CASCADE)
	user_replying = models.ForeignKey(User, on_delete=models.CASCADE)
	message = models.CharField(max_length=2500)
	time = models.DateTimeField(auto_now=True)

	class Meta:
		ordering  = ['time']

	def __str__(self):
		return str(self.user_replying)


class UserContact(models.Model):
	user = models.ForeignKey(User, on_delete=models.CASCADE)
	contact = models.ForeignKey(User, on_delete=models.CASCADE, related_name="contacts", related_query_name="contact")
	time = models.DateTimeField(auto_now=True)


	class Meta:
		ordering  = ['-time']

	def __str__(self):
		return str(self.user) + " -> "+str(self.contact)



#Help Models

class HelpCategory(models.Model):
	category = models.CharField(max_length=100)

	class Meta:
		ordering  = ['-category']

	def __str__(self):
		return self.category


#Help Title

class Help(models.Model):
	category = models.ForeignKey(HelpCategory, on_delete=models.CASCADE)
	topic = models.CharField(max_length=1000)
	time = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.topic


class Step(models.Model):
	topic = models.ForeignKey(Help, on_delete=models.CASCADE)
	step_number = models.IntegerField()
	description = models.TextField(max_length=1000)
	image = models.ImageField(upload_to='hep_images')
	time = models.DateTimeField(auto_now=True)

	class Meta:
		ordering  = ['step_number']

	def __str__(self):
		return str(self.topic)
