from django.contrib import admin
from .models import Profile
from .models import Post
from .models import Comment
from .models import Announcement
from .models import Notification
from .models import RSVP
from .models import Interest
from .models import Video
from .models import Picture
from .models import Career
from .models import About
from .models import CareerFollower
from .models import Event
from .models import Bulletin
from .models import Question
from .models import Conversation
from .models import UserContact
from .models import QuestionReply
from .models import HelpCategory
from .models import Help
from .models import Step

admin.site.register(Profile)
admin.site.register(Post)
admin.site.register(Comment)
admin.site.register(Announcement)
admin.site.register(Notification)
admin.site.register(RSVP)
admin.site.register(Interest)
admin.site.register(Video)
admin.site.register(Picture)
admin.site.register(Career)
admin.site.register(About)
admin.site.register(CareerFollower)
admin.site.register(Event)
admin.site.register(Bulletin)
admin.site.register(Question)
#admin.site.register(Conversation)
admin.site.register(UserContact)
admin.site.register(QuestionReply)
admin.site.register(HelpCategory)
admin.site.register(Help)
admin.site.register(Step)